#ifndef BUZZER_H
#define BUZZER_H

void buzzer_init();
void buzzer_on();
void buzzer_off();
void buzzer_test();
void buzzer_ack();

#endif
